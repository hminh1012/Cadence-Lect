perl .test/test_engine.pl -v .test/config.pl
