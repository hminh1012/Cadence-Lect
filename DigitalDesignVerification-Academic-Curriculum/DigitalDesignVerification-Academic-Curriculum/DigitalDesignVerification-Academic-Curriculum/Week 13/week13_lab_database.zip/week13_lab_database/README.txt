This is the README file for:

        Xcelium Integrated Coverage - version 24.03

After installing the course, source the class_setup C-shell script in this
directory. This shell script sets the path variables to find executables and
libraries. You must source this script in every C-shell in which you run the
tools. MODIFY THIS SCRIPT AS NEEDED FOR YOUR PLATFORM AND SHELLS.

Before you run any Cadence software, verify your patch level with
"checkSysConf XCELIUM20.09" and install any missing required patches.

This lab requires the following software installations:
  -> VMANAGER2403
  -> XCELIUM2403

This lab requires the following software products:
  -> X300 "Xcelium Single-Core"

This lab requires the following software license features:
  -> Xcelium_Single_Core
  -> Integrated_Metrics_Center
  -> Affirma_sim_analysis_env

Although you can expect the Cadence software to run on any platform
Cadence supports, the database is verified only with 20.09 on:
        Linux RH EE 6.5 (64-bit mode)

The lab database is not tested on any other platform or tool version.

UNIX users can test the database with the C-shell script:

        .testscript

The test script tests for the following license features:

  -> Xcelium_Single_Core
  -> Integrated_Metrics_Center

!!! NOTE: The test script currently runs only a Verilog test case
          so you could conceivably encounter VHDL-related problems.

The lab directory hierarchy includes "sources" and "solutions" directories:
- The sources directory contains unmodified lab sources and hidden shell
  scripts to make a new lab and to actually do the lab very much as the
  student would do. You execute these scripts from the student lab directory.
  You do not run anything from within a sources directory.
- The solutions directory contains completed versions of work a student would
  do, but not copies of unmodified sources, so you cannot run anything in a
  solutions directory.
