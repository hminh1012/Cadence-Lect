Module 3 : Identifying Code Coverage

Please refer to the training lab instruction manual PDF document.
