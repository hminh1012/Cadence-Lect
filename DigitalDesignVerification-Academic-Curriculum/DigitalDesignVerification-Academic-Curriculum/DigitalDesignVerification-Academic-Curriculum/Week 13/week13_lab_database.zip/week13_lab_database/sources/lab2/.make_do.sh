#!/bin/sh

  path=`pwd`
  lab=`basename $path`

  ../sources/${lab}/.make_new.sh

  rm -fr results.txt > /dev/null 2>&1
  touch results.txt

  execute () {
     echo "$1 >> $2 2>&1" >> results.txt
     echo "$1 >> $2 2>&1"
     $1 >> $2 2>&1 || {
       echo "#FAIL: ${lab}: $1 >> $2 2>&1" >> results.txt
       echo "#FAIL: ${lab}: $1 >> $2 2>&1"
       exit 1
      }
  }

  echo ""

  for pass in 1 2 3 4 5 6 ; do
    execute "rm -fr xcelium.d cov_work *.history *.key *.log *.tmp" "/dev/null"
    execute "rm -f  report*.txt" "/dev/null"
    case $pass in
    1) execute "xrun -f xrun_args.txt -covdut mic -coverage block" "/dev/null";;
    2) execute "echo select_coverage -b -instance top.dut..." "covfile.txt";
       execute "echo set_assign_scoring" "covfile.txt";
       execute "xrun -f xrun_args.txt -covfile covfile.txt" "/dev/null";;
    3) execute "echo set_branch_scoring" "covfile.txt";
       execute "xrun -f xrun_args.txt -covfile covfile.txt" "/dev/null";;
    4) execute "xrun -f xrun_args.txt -covdut mic -coverage expr" "/dev/null";;
    5) execute "sed s/-b/-e/ covfile.txt" covfile.txt.tmp;
       execute "mv covfile.txt.tmp covfile.txt" "/dev/null";
       execute "echo set_expr_coverable_operators -all" "covfile.txt";
       execute "xrun -f xrun_args.txt -covfile covfile.txt" "/dev/null";;
    6) execute "echo set_expr_coverable_statements -all" "covfile.txt";
       execute "xrun -f xrun_args.txt -covfile covfile.txt" "/dev/null";;
    esac
    execute "grep TEST.PASSED xrun.log" "/dev/null"
    execute "imc -exec ../sources/$lab/.imc.tcl" "/dev/null"
    execute "diff ../solutions/$lab/report-summary-type-be_$pass.txt report-summary-type-be.txt" "/dev/null"
    execute "cp report-summary-type-be.txt ../solutions/$lab/report-summary-type-be_$pass.txt" "/dev/null"
    echo "#PASS: $lab pass $pass" ; echo "#PASS: $lab pass $pass" >> results.txt
    echo "" ; echo "" >> results.txt
  done

  echo "#PASS: $lab" ; echo "#PASS: $lab" >> results.txt
  cp results.txt ../solutions/$lab/
  cp covfile.txt ../solutions/$lab/
  echo ""

