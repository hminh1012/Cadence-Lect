load test
report -summary -type -metrics block:expression -out report-summary-type-be.txt
exit
