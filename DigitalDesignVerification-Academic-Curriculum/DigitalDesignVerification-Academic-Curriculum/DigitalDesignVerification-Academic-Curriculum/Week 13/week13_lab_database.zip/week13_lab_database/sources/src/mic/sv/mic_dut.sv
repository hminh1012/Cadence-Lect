`default_nettype none

module fifo
#(
  parameter int WIDTH=1              , // FIFO width
  parameter int DEPTH=1              , // FIFO depth
  parameter int AWIDTH=$clog2(DEPTH)   // bits to encode pointer
)(
  input  wire logic             clock      ,
  input  wire logic             reset_n    ,
  input  wire logic             write      ,
  input  wire logic [WIDTH-1:0] write_data ,
  input  wire logic             read       ,
  output wire logic [WIDTH-1:0] read_data  ,
  output wire logic             full       ,
  output wire logic             empty       
 );

  timeunit 1ns / 1ns ;

  var logic [ WIDTH-1:0] array [0:DEPTH-1]  ;
  var logic [AWIDTH-1:0] write_pointer, read_pointer ;
  var logic              last_was_write   ;

  always @(posedge clock)
    if (reset_n == 0)
      begin
        write_pointer  <= 0 ;
        read_pointer   <= 0 ;
        last_was_write <= 0 ;
      end
    else
      begin
        if (write && !full)
          begin
            array [write_pointer] <= write_data ;
            if (write_pointer == (DEPTH-1))
              write_pointer <= 0 ;
            else
              write_pointer <= write_pointer + 1 ;
            last_was_write <= 1 ;
          end
        if (read && !empty)
          begin
            if (read_pointer == (DEPTH-1))
              read_pointer <= 0 ;
            else
              read_pointer <= read_pointer + 1 ;
            last_was_write <= 0 ;
          end
      end

  assign full      = (write_pointer == read_pointer) &&  last_was_write ;
  assign empty     = (write_pointer == read_pointer) && !last_was_write ;
  assign read_data = array [read_pointer] ;

endmodule : fifo


module arbiter
#(
  parameter int NREQS=1             , // number of requestors
  parameter int NBITS=$clog2(NREQS)   // bits to encode grant
)(
  input  wire logic             clock       ,
  input  wire logic             reset_n     ,
  input  wire logic             acknowledge ,
  input  wire logic [NREQS-1:0] requests    , // requests
  output var  logic             grant       , // any grant
  output var  logic [NREQS-1:0] grants      , // grant vector
  output var  logic [NBITS-1:0] grant_index   // grant index
 );

  timeunit 1ns / 1ns ;

  var logic [NBITS-1:0] pchain [0:NREQS-1] ; // priority chain
  var logic [NBITS-1:0] selected_index     ; // highest priority chain node
  var logic [NBITS-1:0] selected_grant     ; // request at selected node

  always @*
    begin
      int i ;
      selected_index = 0 ;
      // higher priority chain indices have higher priority
      for (i=0; i<NREQS; i=i+1)
        if (requests[pchain[i]])
          selected_index = i ;
      selected_grant = pchain[selected_index] ;
    end

  integer index2 ;
  always @(posedge clock)
    if (reset_n == 0)
      begin
        for (index2=0; index2<NREQS; index2=index2+1)
          pchain[index2] <= index2 ;
        grant  <= 0 ;
        grants <= 0 ;
      end
    else
      // cannot support consecutive grants to same requestor
      if (|(requests & ~grants) && acknowledge)
        begin
          grant       <= 1 ;
          grants      <= 1 << selected_grant ;
          grant_index <= selected_grant ;
          // move priorities lower than selected higher
          for (index2=0; index2<selected_index; index2=index2+1)
            pchain[index2+1] <= pchain[index2] ;
          // move currently selected priority to lowest
          pchain[0] <= pchain[selected_index] ;
        end
      else
        begin
          grant  <= 0 ;
          grants <= 0 ;
        end

endmodule : arbiter


module multiplexor
#(
  parameter int WIDTH=1             , // width of inputs
  parameter int NINPS=1             , // number of inputs
  parameter int NBITS=$clog2(NINPS)   // bits to select input
)(
  input  wire logic [NBITS-1:0] select         ,
  input  wire logic [WIDTH-1:0] in [0:NINPS-1] ,
  output wire logic [WIDTH-1:0] out              
 );

  timeunit 1ns / 1ns ;

  assign out = in[select] ;

endmodule : multiplexor


module controller
#(
  parameter int NREQS=1             , // number of requestors
  parameter int NBITS=$clog2(NREQS)   // bits to encode grant
 )(
  input  wire logic             request_read            ,
  input  wire logic             request_write           ,
  input  wire logic             arbiter_grant           ,
  input  wire logic [NBITS-1:0] arbiter_grant_index     ,
  output wire logic             cntrl_memory_read       ,
  output wire logic             cntrl_memory_write      ,
  output wire logic [NREQS-1:0] cntrl_memory_read_valid  
 );

  timeunit 1ns / 1ns ;

  assign cntrl_memory_read       = request_read  && arbiter_grant ;
  assign cntrl_memory_write      = request_write && arbiter_grant ;
  assign cntrl_memory_read_valid = cntrl_memory_read? 1<<arbiter_grant_index:0 ;

endmodule : controller


module memory
#(
  parameter int WIDTH=1             , // memory width
  parameter int DEPTH=1             , // memory depth
  parameter int ABITS=$clog2(DEPTH)   // bits for address
)(
  input  wire logic             clock      ,
  input  wire logic             write      ,
  input  wire logic             read       ,
  input  wire logic [ABITS-1:0] address    ,
  input  wire logic [WIDTH-1:0] write_data ,
  output wire logic [WIDTH-1:0] read_data   
 );

  timeunit 1ns / 1ns ;

  var logic [WIDTH-1:0] memory [0:DEPTH-1] ;

  always @(posedge clock)
    if (write) memory[address] <= write_data ;

  assign read_data = read ? memory[address] : 'z ;

endmodule : memory


module mic
#(
  parameter int NREQS=1                , // number of requestors
  parameter int PSIZE=1                , // partition size per requestor
  parameter int MDEPTH=NREQS*PSIZE     , // memory depth
  parameter int AWIDTH=$clog2(MDEPTH)  , // bits to encode address
  parameter int MWIDTH=1               , // memory width
  parameter int RWIDTH=AWIDTH+MWIDTH+2 , // request vector width
  parameter int RDEPTH=1               , // request fifo depth
  parameter int RBITS=$clog2(NREQS)      // bits to encode request/grant
)(
  input  wire logic              clock                         ,
  input  wire logic              reset_n                       ,
  input  wire logic [ NREQS-1:0] test_request_valid            ,
  input  wire logic [RWIDTH-1:0] test_request_data [0:NREQS-1] ,
  output wire logic [ NREQS-1:0] fifo_full                     ,
  output wire logic [ NREQS-1:0] cntrl_memory_read_valid       ,
  output wire logic [AWIDTH-1:0] mux_memory_address            ,
  output wire logic [MWIDTH-1:0] memory_read_data               
 );

  timeunit 1ns / 1ns ;

  wire logic [RWIDTH-1:0] fifo_request_data [0:NREQS-1] ; // fifo   to mux
  wire logic [ NREQS-1:0] fifo_empty                    ; // fifo   to arb
  wire logic              arbiter_grant                 ; // arb    to cntrlr
  wire logic [ NREQS-1:0] arbiter_grant_vector          ; // arb    to fifo
  wire logic [ RBITS-1:0] arbiter_grant_index           ; // arb    to mux
  wire logic [RWIDTH-1:0] mux_request_data              ; // mux    to cntrlr
  wire logic              cntrl_memory_read             ; // cntrlr to mem
  wire logic              cntrl_memory_write            ; // cntrlr to mem

  genvar g ;
  for (g=0; g<NREQS; g=g+1)
    begin : GEN
  fifo
  #(
    .WIDTH ( RWIDTH ) , // fifo width is request width
    .DEPTH ( RDEPTH )   // fifo depth is whatever works
  )
  fifo
  (
    .clock      ( clock                   ), // from testbench
    .reset_n    ( reset_n                 ), // from testbench
    .write      ( test_request_valid[g]   ), // from testbench
    .write_data ( test_request_data[g]    ), // from testbench
    .read       ( arbiter_grant_vector[g] ), // from arbiter
    .read_data  ( fifo_request_data[g]    ), // to multiplexor
    .full       ( fifo_full[g]            ), // to testbench
    .empty      ( fifo_empty[g]           )  // to arbiter
  );
    end


  wire logic [NREQS-1:0] fifo_requests_ready = ~fifo_empty ;
  arbiter
  #(
    .NREQS ( NREQS )   // number of requestors
  )
  arbiter
  (
    .clock       ( clock                ) ,
    .reset_n     ( reset_n              ) ,
    .acknowledge ( 1'b1                 ) ,
    .requests    ( fifo_requests_ready  ) , // from fifo
    .grant       ( arbiter_grant        ) , // to controller
    .grants      ( arbiter_grant_vector ) , // to fifo
    .grant_index ( arbiter_grant_index  )   // to mux, controller
  );


  multiplexor
  #(
    .WIDTH ( RWIDTH ) , // multiplexor width is request width
    .NINPS ( NREQS  )   // number of inputs is number of requestors
  )
  multiplexor
  (
    .select ( arbiter_grant_index ) , // from arbitor
    .in     ( fifo_request_data   ) , // from fifo
    .out    ( mux_request_data    )   // to controller , memory
  );
  assign mux_memory_address = mux_request_data[AWIDTH+1:2] ;
  wire logic [MWIDTH-1:0] mux_write_data = mux_request_data[RWIDTH-1:AWIDTH+2] ;


  controller
  #(
    .NREQS ( NREQS )   // number of requestors
  )
  controller
  (
   .request_read            ( mux_request_data[1]     ) , // from mux
   .request_write           ( mux_request_data[0]     ) , // from mux
   .arbiter_grant           ( arbiter_grant           ) , // from arbiter
   .arbiter_grant_index     ( arbiter_grant_index     ) , // from arbiter
   .cntrl_memory_read       ( cntrl_memory_read       ) , // to memory
   .cntrl_memory_write      ( cntrl_memory_write      ) , // to memory
   .cntrl_memory_read_valid ( cntrl_memory_read_valid )   // to testbench
  );


  memory
  #(
    .WIDTH ( MWIDTH ) , // memory width is data width
    .DEPTH ( MDEPTH )   // memory depth
  )
  memory
  (
    .clock      ( clock              ) ,
    .write      ( cntrl_memory_write ) , // from controller
    .read       ( cntrl_memory_read  ) , // from controller
    .address    ( mux_memory_address ) , // from mux
    .write_data ( mux_write_data     ) , // from mux
    .read_data  ( memory_read_data   )   // to testbench
  );

endmodule : mic
