import tap_pkg::*;

module tap_vcomp 
(
  input wire logic                  TCK         ,
  input wire logic                  clockdr     ,
  input wire logic                  shiftdr     ,
  input wire logic                  updatedr    ,
  input wire logic                  clockir     ,
  input wire logic                  shiftir     ,
  input wire logic                  updateir    ,
  input wire logic [INST_WIDTH-1:0] instruction  
);

  // COVER SOME SIMPLE FSM PATHS
  // Clock - Exit1  - Update
  DR_PATH1: cover sequence ( @(posedge TCK) clockdr ##1 !shiftdr ##1 updatedr );
  IR_PATH1: cover sequence ( @(posedge TCK) clockir ##1 !shiftir ##1 updateir );
  // Clock - Shift+ - Exit1 - Update
  DR_PATH2: cover sequence ( @(posedge TCK) clockdr ##1 shiftdr[*1:$] ##1 !shiftdr ##1 updatedr );
  IR_PATH2: cover sequence ( @(posedge TCK) clockir ##1 shiftir[*1:$] ##1 !shiftir ##1 updateir );
  // Clock - Shift+ - Exit1 - Pause+ - Exit2 - Update
  DR_PATH3: cover sequence ( @(posedge TCK) clockdr ##1 shiftdr[*1:$] ##1 !shiftdr[*3:$] ##1 updatedr );
  IR_PATH3: cover sequence ( @(posedge TCK) clockir ##1 shiftir[*1:$] ##1 !shiftir[*3:$] ##1 updateir );
  // Clock - Shift+ - Exit1 - Pause+ - Exit2 - Shift+ - Exit1 - Update
  DR_PATH4: cover sequence ( @(posedge TCK) clockdr ##1 shiftdr[*1:$] ##1 !shiftdr[*3:$] ##1 shiftdr[*1:$] ##1 !shiftdr ##1 updatedr );
  IR_PATH4: cover sequence ( @(posedge TCK) clockir ##1 shiftir[*1:$] ##1 !shiftir[*3:$] ##1 shiftir[*1:$] ##1 !shiftir ##1 updateir );

 // COVER THE DEFINED INSTRUCTIONS
  covergroup tap_cg @(posedge TCK iff updateir);
    option.per_instance = 1 ;
    coverpoint instruction {
      bins DESIGN_DATA   = {DESIGN_DATA}   ;
      bins INST_BYPASS   = {INST_BYPASS}   ;
      bins INST_EXTEST   = {INST_EXTEST}   ;
      bins INST_SAMPLE   = {INST_SAMPLE}   ;
      bins INST_INTEST   = {INST_INTEST}   ;
      bins INST_RUNBIST  = {INST_RUNBIST } ;
      bins INST_CLAMP    = {INST_CLAMP}    ;
      bins INST_HIGHZ    = {INST_HIGHZ}    ;
      bins INST_IDCODE   = {INST_IDCODE}   ;
      bins INST_USERCODE = {INST_USERCODE} ;
      bins DEFAULT       = default         ;
    }
  endgroup
  tap_cg tap_cg_i = new ;

endmodule : tap_vcomp


bind tap
tap_vcomp
tap_vcomp
(
  .TCK         ,
  .clockdr     ,
  .shiftdr     ,
  .updatedr    ,
  .clockir     ,
  .shiftir     ,
  .updateir    ,
  .instruction  
);

