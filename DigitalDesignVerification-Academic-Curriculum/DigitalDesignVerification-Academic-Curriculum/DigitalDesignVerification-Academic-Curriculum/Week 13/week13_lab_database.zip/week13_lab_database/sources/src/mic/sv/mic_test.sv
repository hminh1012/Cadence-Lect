`default_nettype none

module mic_test
#(
  parameter int DEBUG=0                , // diagnostic verbosity
  parameter int NTRANS=1               , // number write/read transactions
  parameter int INTVL=1                , // mean interval between requests
  parameter int NREQS=1                , // number of requestors
  parameter int PSIZE=1                , // partition size per requestor
  parameter int MDEPTH=NREQS*PSIZE     , // memory depth
  parameter int AWIDTH=$clog2(MDEPTH)  , // bits to encode address
  parameter int MWIDTH=1               , // memory width
  parameter int RWIDTH=AWIDTH+MWIDTH+2 , // request vector width
  parameter int RDEPTH=1                 // request fifo depth
)(
  input  wire logic              clock                         ,
  output var  logic              reset_n                       ,
  output var  logic [ NREQS-1:0] test_request_valid            ,
  output var  logic [RWIDTH-1:0] test_request_data [0:NREQS-1] ,
  input  wire logic [ NREQS-1:0] fifo_full                     ,
  input  wire logic [ NREQS-1:0] cntrl_memory_read_valid       ,
  input  wire logic [AWIDTH-1:0] mux_memory_address            ,
  input  wire logic [MWIDTH-1:0] memory_read_data               
 );

  timeunit 1ns / 1ns ;

  var bit   [MWIDTH-1:0] data_written[int]              ;
  var logic [MWIDTH-1:0] data_expected [MDEPTH-1:0] [$] ; // can expect unknown
  var int                reads_requested[NREQS], reads_received[NREQS] ;

  task automatic requestor (input int device);
    begin
      var bit [MWIDTH-1:0] data       ;
      var bit [AWIDTH-1:0] address    ;
      var bit [       1:0] read_write ;
      var int              seed       ;
      if (DEBUG>=2) $display("Time %t: Device %0d starting",$time,device);
      repeat (NTRANS)
        begin // TRANS
          address    = device * PSIZE + $urandom%PSIZE ;
          read_write = $urandom%2 + 1 ; // read(2) or write(1)
          data=$urandom ;
          case (read_write)
            1: data_written[address] = data ;
            2: begin data_expected[address].push_front(data_written.exists(address)?data_written[address]:'bx); ++reads_requested[device]; end
          endcase
          seed = $urandom;
          repeat ($dist_exponential(seed,INTVL)) @(negedge clock);
          while (fifo_full[device]) begin
            if (DEBUG>=2) $display("Time %t: Device %0d stalled",$time,device);
            @(negedge clock);
          end
          if (DEBUG>=1)
            $display("Time %t: Device %0d %s address=%h data=%h",
                     $time,device,(read_write==1)?"writing ":"reading ",address,data);
          test_request_data  [device] <= {data, address, read_write};
          test_request_valid [device] <= 1; @(negedge clock);
          test_request_valid [device] <= 0; @(negedge clock);
        end // TRANS
    end
  endtask : requestor

  initial begin : monitor
    @(posedge reset_n);
    forever @(negedge clock)
      if (cntrl_memory_read_valid) begin : data_received
        logic [MWIDTH-1:0] popped_expect_data ;
        for (int device=0; device<NREQS; device++)
          if (cntrl_memory_read_valid[device]) begin // should be only one
            ++reads_received[device];
            if (DEBUG>=1)
              $display("Time %t: Device %0d returned address=%h data=%h",
                       $time, device, mux_memory_address, memory_read_data);
          end
        expect_exists: assert (data_expected[mux_memory_address].size())
          else $finish;
        popped_expect_data = data_expected[mux_memory_address].pop_back() ;
        data_check: assert (memory_read_data === popped_expect_data)
        else
          begin
            $display("address=%h memory_read_data=%h popped_expect_data=%h",
                     mux_memory_address, memory_read_data, popped_expect_data) ;
            $finish;
          end
      end // data_received
  end : monitor

  initial begin // stimulus
    var bit failed ;
    $timeformat(-9,0,"",4);
    @(negedge clock) reset_n=0;
    @(negedge clock) reset_n=1; test_request_valid=0;
    @(negedge clock) for (int device=0; device < NREQS; device++)
                       begin fork requestor(device); join_none #0; end
    wait fork ;
    repeat (NREQS*RDEPTH*2) @(negedge clock) ; // flush FIFOs
    failed = 0 ;
    for (int device=0; device < NREQS; ++device) begin
      if (reads_received[device] != reads_requested[device]) failed = 1 ;
      if (DEBUG>=1)
        $display("Device %0d requested %0d reads and received %0d",
                  device, reads_requested[device], reads_received[device]);
    end
    $display(failed?"TEST FAILED":"TEST PASSED");
    $finish;
  end

endmodule : mic_test
