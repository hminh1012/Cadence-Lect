`default_nettype none

import tap_pkg::*;

module tap_test ;

  var  logic TCK ;
  var  logic TMS ;
  var  logic TDI ;
  wire logic TDO ;

  // INSTANTIATE TAP
  tap
  tap
  (
    .TCK ,
    .TMS ,
    .TDI ,
    .TDO  
  ) ;
 
  // COUNT NEGATIVE CLOCK EDGES
  task clockn (input int count);
    repeat (count) @(negedge TCK);
  endtask

  // COUNT POSITIVE CLOCK EDGES
  task clockp (input int count);
    repeat (count) @(posedge TCK);
  endtask

  // CHECK RESULTS
  task check (input logic e);
    if (e !== 1'bx)
      if (TDO !== e) begin
          $display ( "TEST FAILED: TDO=%b s/b=%b", TDO, e ) ;
      //  $finish ;
          $stop ;
        end
  endtask

  // TEST BYPASS REGISTER
  task test_br ;
    begin
      var logic [29:0] TMS_STREAM,TDI_STREAM,TDO_STREAM;
      TMS_STREAM = 30'b011010111000100100001001111110;
      TDI_STREAM = 30'bxxxxxxxxx01xxxxx10xxxxxxxxxxxx;
      TDO_STREAM = 30'bzzzzzzzz01xzzzz10xzzzzzzxxxxxx;
      $display ( "DOING DATA REG TEST" ) ;
      for (int unsigned i=0;i<=29;++i) begin
          TMS = TMS_STREAM[i];
          TDI = TDI_STREAM[i];
          @(posedge TCK);
          check(TDO_STREAM[i]);
          @(negedge TCK);
        end
      $display ( "DATA REG TEST PASSED" ) ;
    end
  endtask

  // TEST INSTRUCTION REGISTER
  task test_ir ;
    begin
      var logic [36:0] TMS_STREAM,TDI_STREAM,TDO_STREAM;
      TMS_STREAM = 37'b1110110101111010010000000011001111110;
      TDI_STREAM = 37'bxxxxxxxxxxxx0xxxx0000001xxxxxxxxxxxxx;
      TDO_STREAM = 37'bzzzzzzzzzzzz1zzzz0000001zzzzzzzxxxxxx;
      $display ( "DOING INST REG TEST" ) ;
      for (int unsigned i=0;i<=36;++i) begin
          TMS = TMS_STREAM[i];
          TDI = TDI_STREAM[i];
          @(posedge TCK);
          check(TDO_STREAM[i]);
          @(negedge TCK);
        end
      $display ( "INST REG TEST PASSED" ) ;
    end
  endtask

  // GENERATE CLOCK
  always begin
      TCK <= 1; #(PERIOD/2);
      TCK <= 0; #(PERIOD/2);
    end

  // APPLY STIMULUS
  var int testnum ; // select test via user interface
  initial
    begin
      @(negedge TCK);
      case (testnum)
        2       : test_ir;
        default : test_br;
      endcase
      $display ("TEST PASSED");
      $finish;
    end

endmodule : tap_test

