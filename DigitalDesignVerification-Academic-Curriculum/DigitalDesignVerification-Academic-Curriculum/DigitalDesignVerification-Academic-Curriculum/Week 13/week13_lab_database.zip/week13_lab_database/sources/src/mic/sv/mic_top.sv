`default_nettype none

module top ;

  timeunit 1ns / 1ns ;

  import mic_pkg::* ;

  var  logic              clock                         ; // top  to test/dut
  wire logic              reset_n                       ; // test to dut
  wire logic [ NREQS-1:0] test_request_valid            ; // test to dut
  wire logic [RWIDTH-1:0] test_request_data [0:NREQS-1] ; // test to dut
  wire logic [ NREQS-1:0] fifo_full                     ; // dut  to test
  wire logic [ NREQS-1:0] cntrl_memory_read_valid       ; // dut  to test
  wire logic [AWIDTH-1:0] mux_memory_address            ; // dut  to test
  wire logic [MWIDTH-1:0] memory_read_data              ; // dut  to test

  mic
  #(
    .NREQS  ( NREQS  ) , // number of requestors
    .PSIZE  ( PSIZE  ) , // partition size per requestor
    .MWIDTH ( MWIDTH ) , // memory width
    .RDEPTH ( RDEPTH )   // request fifo depth
  )
  dut
  (
    .clock                    ( clock                    ) ,
    .reset_n                  ( reset_n                  ) ,
    .test_request_valid       ( test_request_valid       ) ,
    .test_request_data        ( test_request_data        ) ,
    .fifo_full                ( fifo_full                ) , // from fifo
    .cntrl_memory_read_valid  ( cntrl_memory_read_valid  ) , // from controller
    .mux_memory_address       ( mux_memory_address       ) , // from multiplexor
    .memory_read_data         ( memory_read_data         )   // from memory
  );

  mic_test
  #(
    .DEBUG  ( DEBUG  ) , // diagnostic verbosity
    .NTRANS ( NTRANS ) , // number write/read transactions
    .INTVL  ( INTVL  ) , // mean interval between requests
    .NREQS  ( NREQS  ) , // number of requestors
    .PSIZE  ( PSIZE  ) , // partition size per requestor
    .MWIDTH ( MWIDTH ) , // memory width
    .RDEPTH ( RDEPTH )   // request fifo depth
  )
  test
  (
    .clock                    ( clock                    ) ,
    .reset_n                  ( reset_n                  ) ,
    .test_request_valid       ( test_request_valid       ) ,
    .test_request_data        ( test_request_data        ) ,
    .fifo_full                ( fifo_full                ) , // from fifo
    .cntrl_memory_read_valid  ( cntrl_memory_read_valid  ) , // from controller
    .mux_memory_address       ( mux_memory_address       ) , // from multiplexor
    .memory_read_data         ( memory_read_data         )   // from memory
  );

  always begin
    clock=0; #1;
    clock=1; #1;
  end

endmodule : top
