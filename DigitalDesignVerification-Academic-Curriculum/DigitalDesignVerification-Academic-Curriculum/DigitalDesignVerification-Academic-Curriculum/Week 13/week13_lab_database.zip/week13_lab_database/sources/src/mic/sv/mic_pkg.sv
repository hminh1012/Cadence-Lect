package mic_pkg ;
  localparam int DEBUG=2                ; // diagnostic verbosity
  localparam int NTRANS=100             ; // number write/read transactions
  localparam int INTVL=4                ; // mean interval between requests
  localparam int NREQS=5                ; // number of requestors
  localparam int RBITS=$clog2(NREQS)    ; // bits to encode request/grant
  localparam int PSIZE=20               ; // partition size per requestor
  localparam int MDEPTH=NREQS*PSIZE     ; // memory depth
  localparam int AWIDTH=$clog2(MDEPTH)  ; // bits to encode address
  localparam int MWIDTH=20              ; // memory width
  localparam int RWIDTH=AWIDTH+MWIDTH+2 ; // request vector width
  localparam int RDEPTH=6               ; // request fifo depth
endpackage : mic_pkg
