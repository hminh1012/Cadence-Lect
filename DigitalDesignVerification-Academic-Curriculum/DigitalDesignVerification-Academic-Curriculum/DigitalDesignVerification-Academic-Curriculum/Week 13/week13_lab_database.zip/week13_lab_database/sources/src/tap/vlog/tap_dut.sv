`default_nettype none

import tap_pkg::*;

module fsm
(
  input  wire logic TCK      ,
  input  wire logic TMS      ,
  output wire logic reset    ,
  output wire logic clockdr  ,
  output wire logic shiftdr  ,
  output wire logic updatedr ,
  output wire logic clockir  ,
  output wire logic shiftir  ,
  output wire logic updateir ,
  output wire logic sel_ir   ,
  output wire logic enable    
) ;

  // Testbench construct to force initial state
  // Fifth clock with TMS==1 goes to FSM_RESET
  // rtl_synthesis off
  // pragma coverage off
  var logic [2:0] count ;
  always @(posedge TCK)
    if ( TMS == 1'b0 )
        count <= 3'b000 ;
    else
      if ( count != 3'b111 )
        count <= count + 3'b001 ;
  // pragma coverage on
  // rtl_synthesis on

  var logic [3:0] state ; // variable

  always @(posedge TCK)
    begin
    // rtl_synthesis off
    // pragma coverage off
      if ( count == 3'b100 && TMS == 1'b1 )
        state <= FSM_RESET ;
      else
    // pragma coverage on
    // rtl_synthesis on

        case ( state )
FSM_RESET    : if (TMS==1'b1) state <= FSM_RESET   ; else state <= FSM_IDLE    ;
FSM_IDLE     : if (TMS==1'b1) state <= FSM_DRSCAN  ; else state <= FSM_IDLE    ;
FSM_DRSCAN   : if (TMS==1'b1) state <= FSM_IRSCAN  ; else state <= FSM_DRCLOCK ;
FSM_DRCLOCK  : if (TMS==1'b1) state <= FSM_DREXIT1 ; else state <= FSM_DRSHIFT ;
FSM_DRSHIFT  : if (TMS==1'b1) state <= FSM_DREXIT1 ; else state <= FSM_DRSHIFT ;
FSM_DREXIT1  : if (TMS==1'b1) state <= FSM_DRUPDATE; else state <= FSM_DRPAUSE ;
FSM_DRPAUSE  : if (TMS==1'b1) state <= FSM_DREXIT2 ; else state <= FSM_DRPAUSE ;
FSM_DREXIT2  : if (TMS==1'b1) state <= FSM_DRUPDATE; else state <= FSM_DRSHIFT ;
FSM_DRUPDATE : if (TMS==1'b1) state <= FSM_DRSCAN  ; else state <= FSM_IDLE    ;
FSM_IRSCAN   : if (TMS==1'b1) state <= FSM_RESET   ; else state <= FSM_IRCLOCK ;
FSM_IRCLOCK  : if (TMS==1'b1) state <= FSM_IREXIT1 ; else state <= FSM_IRSHIFT ;
FSM_IRSHIFT  : if (TMS==1'b1) state <= FSM_IREXIT1 ; else state <= FSM_IRSHIFT ;
FSM_IREXIT1  : if (TMS==1'b1) state <= FSM_IRUPDATE; else state <= FSM_IRPAUSE ;
FSM_IRPAUSE  : if (TMS==1'b1) state <= FSM_IREXIT2 ; else state <= FSM_IRPAUSE ;
FSM_IREXIT2  : if (TMS==1'b1) state <= FSM_IRUPDATE; else state <= FSM_IRSHIFT ;
FSM_IRUPDATE : if (TMS==1'b1) state <= FSM_DRSCAN  ; else state <= FSM_IDLE    ;
default      : ;
        endcase
    end

  assign reset    = ( state == FSM_RESET    ) ? 1'b1 : 1'b0 ;
  assign clockdr  = ( state == FSM_DRCLOCK  ) ? 1'b1 : 1'b0 ;
  assign shiftdr  = ( state == FSM_DRSHIFT  ) ? 1'b1 : 1'b0 ;
  assign updatedr = ( state == FSM_DRUPDATE ) ? 1'b1 : 1'b0 ;
  assign clockir  = ( state == FSM_IRCLOCK  ) ? 1'b1 : 1'b0 ;
  assign shiftir  = ( state == FSM_IRSHIFT  ) ? 1'b1 : 1'b0 ;
  assign updateir = ( state == FSM_IRUPDATE ) ? 1'b1 : 1'b0 ;
  assign sel_ir   = ( state == FSM_IRSHIFT  ) ? 1'b1 : 1'b0 ;
  assign enable   = ( state == FSM_DRSHIFT
                   || state == FSM_IRSHIFT  ) ? 1'b1 : 1'b0 ;

endmodule : fsm


module ireg
(
  input  wire logic                  TCK         ,
  input  wire logic                  reset       ,
  input  wire logic                  clockir     ,
  input  wire logic                  shiftir     ,
  input  wire logic                  updateir    ,
  input  wire logic                  TDI         ,
  output var  logic [INST_WIDTH-1:0] instruction ,
  output wire logic                  tdo_ir       
) ;

  var logic [INST_WIDTH-1:0] instruction_shifter;

  always @(posedge TCK or posedge reset)
    if ( clockir == 1'b1 )
      instruction_shifter <= DESIGN_DATA ;
    else
      if ( shiftir == 1'b1 )
        instruction_shifter <= { TDI, instruction_shifter[INST_WIDTH-1:1] } ;

  always @(negedge TCK or posedge reset)
      if ( reset == 1'b1 )
          instruction <= INST_BYPASS ;
      else 
        if ( updateir == 1'b1 )
          instruction <= instruction_shifter ;

  assign tdo_ir = instruction_shifter[0] ;

endmodule : ireg


module breg // BYPASS REGISTER
(
  input  wire logic                  TCK         ,
  input  wire logic                  reset       , // used only for refinement
  input  wire logic [INST_WIDTH-1:0] instruction ,
  input  wire logic                  shiftdr     ,
  input  wire logic                  TDI         ,
  output var  logic                  TDO_br       
) ;

  always @(posedge TCK)
    if ( instruction == INST_BYPASS && shiftdr == 1'b1 )
      TDO_br <= TDI ;

endmodule : breg


module dreg // DATA REGISTER
(
  input  wire logic                  TCK         ,
  input  wire logic                  reset       , // used only for refinement
  input  wire logic [INST_WIDTH-1:0] instruction ,
  input  wire logic                  shiftdr     ,
  input  wire logic                  TDI         ,
  output var  logic                  tdo_dr       
) ;

  wire logic TDO_br ;

  // INSTANTIATE DATA REGISTERS
  breg // BYPASS REGISTER
  breg
  (
    .TCK         (  TCK        ) ,
    .reset       (  /*  NC  */ ) , // unconnected, leave for refinement
    .instruction ( instruction ) ,
    .shiftdr     ( shiftdr     ) ,
    .TDI         ( TDI         ) ,
    .TDO_br      ( TDO_br      )  
  ) ;

  // SELECT DATA REGISTERS
  always @*
    case (instruction)
      INST_BYPASS : tdo_dr = TDO_br ;
      default     : tdo_dr = 1'b0   ;
    endcase

endmodule : dreg


module mux // TDO MUX
(
  input  wire logic sel_ir ,
  input  wire logic tdo_dr ,
  input  wire logic tdo_ir ,
  output wire logic tdo_mx  
) ;
  assign tdo_mx = sel_ir ? tdo_ir : tdo_dr ;
endmodule : mux


module oreg // TDO REGISTER
(
  input  wire logic TCK    ,
  input  wire logic tdo_mx ,
  output var  logic tdo_rg  
) ;
  always @(negedge TCK)
    tdo_rg <= tdo_mx ;
endmodule : oreg


module drvr // TDO DRIVER
(
  input  wire logic enable ,
  input  wire logic tdo_rg ,
  output wire logic TDO     
) ;
  assign TDO = enable ? tdo_rg : 1'bz ;
endmodule : drvr


module tap
(
  input  wire logic TCK ,
  input  wire logic TMS ,
  input  wire logic TDI ,
  output wire logic TDO  
) ;

  wire logic                  reset       ;
  wire logic                  clockdr     ;
  wire logic                  shiftdr     ;
  wire logic                  updatedr    ;
  wire logic                  clockir     ;
  wire logic                  shiftir     ;
  wire logic                  updateir    ;
  wire logic                  sel_ir      ;
  wire logic                  enable      ;
  wire logic [INST_WIDTH-1:0] instruction ;
  wire logic                  tdo_ir      ;
  wire logic                  tdo_dr      ;
  wire logic                  tdo_mx      ;
  wire logic                  tdo_rg      ;

  fsm // CONTROLLER FSM
  fsm
  (
    .TCK      ,
    .TMS      ,
    .reset    , // to instruction register
    .clockdr  , // to data register
    .shiftdr  , // to data register
    .updatedr , // to data register
    .clockir  , // to instruction register
    .shiftir  , // to instruction register
    .updateir , // to instruction register
    .sel_ir   , // to TDO mux
    .enable     // to TDO driver
  ) ;

  ireg // INSTRUCTION REGISTER
  ireg
  (
    .TCK         ,
    .reset       , // from FSM
    .clockir     , // from FSM
    .updateir    , // from FSM
    .shiftir     , // from FSM
    .TDI         , // TDI input
    .instruction , // to data register
    .tdo_ir        // to TDO mux
  ) ;

  dreg // DATA REGISTER
  dreg
  (
    .TCK         ,
    .reset       , // used only for refinement
    .instruction , // from instruction register
    .shiftdr     , // from FSM
    .TDI         , // from TDI input
    .tdo_dr        // to TDO mux
  ) ;

  mux // TDO MUX
  mux
  (
    .sel_ir , // from FSM
    .tdo_dr , // from data register
    .tdo_ir , // from instruction register
    .tdo_mx   // to TDO register
  ) ;

  oreg // TDO REGISTER
  oreg
  (
    .TCK    ,
    .tdo_mx , // from TDO mux
    .tdo_rg   // to TDO driver
  ) ;

  drvr // TDO DRIVER
  drvr
  (
    .enable ,
    .tdo_rg , // from TDO register
    .TDO      // to TDO output
  ) ;

endmodule : tap
