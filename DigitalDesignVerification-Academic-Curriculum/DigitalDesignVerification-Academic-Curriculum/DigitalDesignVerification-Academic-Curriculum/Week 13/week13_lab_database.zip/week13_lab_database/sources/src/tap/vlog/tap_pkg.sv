package tap_pkg;

// CONSTANT DEFINITIONS

  // FSM STATES

  localparam bit [3:0] FSM_RESET    =  4'd0 ;
  localparam bit [3:0] FSM_IDLE     =  4'd1 ;
  localparam bit [3:0] FSM_DRSCAN   =  4'd2 ;
  localparam bit [3:0] FSM_DRCLOCK  =  4'd3 ;
  localparam bit [3:0] FSM_DRSHIFT  =  4'd4 ;
  localparam bit [3:0] FSM_DREXIT1  =  4'd5 ;
  localparam bit [3:0] FSM_DRPAUSE  =  4'd6 ;
  localparam bit [3:0] FSM_DREXIT2  =  4'd7 ;
  localparam bit [3:0] FSM_DRUPDATE =  4'd8 ;
  localparam bit [3:0] FSM_IRSCAN   =  4'd9 ;
  localparam bit [3:0] FSM_IRCLOCK  =  4'd10 ;
  localparam bit [3:0] FSM_IRSHIFT  =  4'd11 ;
  localparam bit [3:0] FSM_IREXIT1  =  4'd12 ;
  localparam bit [3:0] FSM_IRPAUSE  =  4'd13 ;
  localparam bit [3:0] FSM_IREXIT2  =  4'd14 ;
  localparam bit [3:0] FSM_IRUPDATE =  4'd15 ;

  // CLOCK PERIOD

  localparam int unsigned PERIOD = 10 ;

  // INSTRUCTION WIDTH

  localparam int unsigned INST_WIDTH = 7 ;

  // REQUIRED INSTRUCTIONS

  // initial IR contents is design data - last two bits must be 01
  localparam bit [INST_WIDTH-1:0] DESIGN_DATA   =   1 ;
  // bypass instruction is all ones
  localparam bit [INST_WIDTH-1:0] INST_BYPASS   =  -1 ;
  // extest instruction is all zeroes
  localparam bit [INST_WIDTH-1:0] INST_EXTEST   =   0 ;
  // sample/preload instruction is vendor-defined value
  localparam bit [INST_WIDTH-1:0] INST_SAMPLE   =   1 ;

  // OPTIONAL INSTRUCTIONS - VENDOR-DEFINED VALUES

  localparam bit [INST_WIDTH-1:0] INST_INTEST   =  2 ;
  localparam bit [INST_WIDTH-1:0] INST_RUNBIST  =  4 ;
  localparam bit [INST_WIDTH-1:0] INST_CLAMP    =  8 ;
  localparam bit [INST_WIDTH-1:0] INST_HIGHZ    =  16 ;
  localparam bit [INST_WIDTH-1:0] INST_IDCODE   =  32 ;
  localparam bit [INST_WIDTH-1:0] INST_USERCODE =  64 ;

endpackage : tap_pkg

