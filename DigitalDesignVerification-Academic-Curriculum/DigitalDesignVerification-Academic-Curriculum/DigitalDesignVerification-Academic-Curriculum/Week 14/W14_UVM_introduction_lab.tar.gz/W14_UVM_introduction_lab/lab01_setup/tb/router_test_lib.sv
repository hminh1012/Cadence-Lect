/*-----------------------------------------------------------------
File name     : router_test_lib.sv
Developers    : Kathleen Meade, Brian Dickinson
Created       : 01/04/11
Description   : lab03_test YAPP test library
Notes         : From the Cadence "SystemVerilog Accelerated Verification with UVM" training
-------------------------------------------------------------------
Copyright Cadence Design Systems (c)2015
-----------------------------------------------------------------*/

//------------------------------------------------------------------------------
//
// CLASS: test_lib
//
//------------------------------------------------------------------------------

class base_test extends uvm_test;

  // component macro
  `uvm_component_utils(base_test)

  router_tb tb;

  // handle on YAPP sequencer
  yapp_tx_sequencer yapp_seqr;

  // handle on YAPP 5 packets sequence
  yapp_5_packets yapp5;


  // component constructor
  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction : new

  // UVM build_phase()
  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    // create testbench instance
    tb = router_tb::type_id::create("tb", this);

    // create sequence instance
    // syntax is:
    // <handle_name> = <handle_type>::type_id::create("<handle_name>",this);
    //yapp5 = yapp_5_packets::type_id::create("yapp5", this);

    
  endfunction : build_phase
  
  function void connect_phase(uvm_phase phase);
    // assign sequencer handle to the pathname of the YAPP sequencer, as read
    // from the topology report
    //yapp_seqr = tb.
  endfunction : connect_phase

  function void end_of_elaboration_phase(uvm_phase phase);
    uvm_top.print_topology();
  endfunction : end_of_elaboration_phase

  task run_phase(uvm_phase phase);
    // do NOT move or delete the objection handling calls
    phase.raise_objection(this, "yapp_base_seq");

    // start sequences here
    // syntax is:
    //   <sequence_handle>.start(yapp_seqr);
    //yapp5.start(yapp_seqr); 

    phase.drop_objection(this, "yapp_base_seq");
  endtask : run_phase

endclass : base_test

class seq_from_test extends base_test;

  // component macro
  `uvm_component_utils(seq_from_test)

  yapp_tx_sequencer yapp_seqr;
  yapp_5_packets yapp5;

  // component constructor
  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction : new

  function void build_phase(uvm_phase phase);
   yapp5 = yapp_5_packets::type_id::create("yapp5", this);
   super.build_phase(phase);
  endfunction : build_phase

  function void connect_phase(uvm_phase phase);
    yapp_seqr = tb.yapp.tx_agent.sequencer;
  endfunction : connect_phase

  task run_phase(uvm_phase phase);
    phase.raise_objection(this, "yapp_base_seq");
    yapp5.start(yapp_seqr); 
    phase.drop_objection(this, "yapp_base_seq");
  endtask : run_phase

endclass : seq_from_test

