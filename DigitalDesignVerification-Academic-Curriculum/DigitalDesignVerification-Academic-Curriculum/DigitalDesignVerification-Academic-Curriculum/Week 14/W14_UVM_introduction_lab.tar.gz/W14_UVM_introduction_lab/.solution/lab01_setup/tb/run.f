/*-----------------------------------------------------------------
File name     : run.f
Developers    : Kathleen Meade, Brian Dickinson
Created       : 01/04/11
Description   : lab01_setup simulator run file
Notes         : From the Cadence "SystemVerilog Accelerated Verification with UVM" training
-------------------------------------------------------------------
Copyright Cadence Design Systems (c)2019
-----------------------------------------------------------------*/
// 64 bit option required for AWS labs
-64

-uvmhome $UVMHOME

// include directories
-incdir ../sv

// UVM command line options
// Set visibility of UVM reports
+UVM_VERBOSITY=UVM_MEDIUM
// Select test to run
+UVM_TESTNAME=base_test

// uncomment to randomize seed for different results on every run
//+SVSEED=random 

// compile YAPP UVC files from package
../sv/yapp_pkg.sv

// compile top module
top.sv

